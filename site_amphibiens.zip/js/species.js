
const params = new URLSearchParams(window.location.search);
const id = params.get("id");

fetch("data/species.json")
  .then(response => response.json())
  .then(data => {
    const species = data.find(s => s.id === id);
    if (species) {
      document.getElementById("nom").textContent = species.nom_commun;
      document.getElementById("scientifique").textContent = species.nom_scientifique;
      document.getElementById("photo").src = species.image;
      document.getElementById("audio").src = species.audio;
    } else {
      document.getElementById("content").innerHTML = "<p>Espèce non trouvée.</p>";
    }
  });
